# 분양 접수 운영 구현 기준

참고 구현: `assets/intake/`의 app.js, auth.js, validate.js, schema.js, admin.js.
`app.js`·`schema.js`에는 4단계(사이트 콘텐츠 운영)의 content·popups 라우트와 테이블도 함께 들어 있다. 이 단계에서는 applications·settings·login_attempts와 신청·인증·관리자 라우트만 옮긴다.

## 데이터 (Turso / libSQL)
- `applications`: 이름, 연락처(표시용 + 숫자만), 관심타입, 방문희망일, 문의, 개인정보 동의(필수), 마케팅 동의(선택), 상태, 관리자 메모, 생성·수정 시각
  - 시각은 한국시간 문자열(`YYYY-MM-DD HH:MM:SS`)로 저장해서 기간 조회를 단순하게 한다.
- `settings`: key/value — `apply_closed`, `closed_title`, `closed_message`
- `login_attempts`: ip, 시각 — 로그인 실패 제한용
- 스키마는 서버가 처음 요청을 받을 때 `CREATE TABLE IF NOT EXISTS`로 보장한다(배포 후 마이그레이션 단계 불필요).
- 상태 값: 신규 / 연락완료 / 방문예약 / 계약 / 보류
- 관심 타입은 카탈로그 타입 목록과 같게 한다(2단계의 units 데이터와 일치).

## 신청 API
- `GET /api/public/settings` → 마감 여부, 마감 안내 문구, 타입 목록
- `POST /api/applications`
  - 마감 상태면 `403 { code: 'APPLICATIONS_CLOSED', title, message }` — **화면을 숨기는 것과 별개로 서버가 반드시 거부한다.**
  - 서버 검증: 이름(한글·영문 2~20자), 휴대폰(01X 형식), 타입(목록 안), 방문희망일(오늘~180일), 문의 500자, 개인정보 동의 필수
  - 24시간 안에 같은 번호로 다시 신청하면 409
  - 허니팟 필드(`website`)가 채워져 있으면 저장하지 않고 성공처럼 응답
  - 요청 크기 제한(bodyLimit)

## 인증
- `POST /api/auth/login`: 비밀번호를 `ADMIN_PASSWORD`와 상수시간 비교(sha256 digest + timingSafeEqual)
- 성공 시 `ADMIN_TOKEN_SECRET`(32자 이상)으로 서명한 JWT(HS256, 8시간)를 HttpOnly·SameSite=Strict 쿠키로 발급
  - 함께 HttpOnly가 아닌 표시용 쿠키(`xi_admin_ui=1`)를 둔다. 값은 비밀이 아니며, 4단계에서 "편집기를 불러올지 서버에 물어볼지" 판단하는 데만 쓴다.
- 15분 안에 5회 실패하면 429
- `GET /api/auth/me`, `POST /api/auth/logout`
- 관리자 라우트(`/api/admin/*`)는 전부 미들웨어에서 토큰을 서버 검증한다.

## 관리자 API
- `GET /api/admin/applications?q&status&unitType&from&to&page&size` → 목록, 총건수, 상태별 건수
  - 검색: 이름·문의·메모, 숫자 3자리 이상이면 연락처 숫자도
  - 기간: 신청일 `from 00:00:00` ~ `to 23:59:59`
- `GET /api/admin/applications.csv` (목록과 같은 필터)
  - UTF-8 BOM(엑셀 한글), `=`/`+`/`-`/`@`로 시작하는 값 앞에 `'`를 붙여 수식 주입 방지, 파일명에 날짜
- `PATCH /api/admin/applications/:id` 상태·메모
- `DELETE /api/admin/applications` `{ ids: [] }` (개별·일괄 공용, 확인 후 실행)
- `GET/PUT /api/admin/settings` 마감 스위치·안내 문구

## 신청 화면 (`apply.html`)
- 디자인 시스템 그대로: 헤더·푸터 partial, 상단 네이비 패턴 히어로, 좌측 단지 요약 카드, 우측 폼
- 폼과 마감 안내는 `<template>`에 두고, 설정을 받아온 뒤 **마감이면 폼을 렌더링하지 않고** 안내만 붙인다.
- 타입은 칩 버튼(라디오), `?type=84B`로 미리 선택
- 휴대폰 자동 하이픈, 클라이언트 검증 + 서버 오류 메시지 필드별 표시, 중복 제출 방지
- 완료 화면, 개인정보 수집·이용 안내(수집 항목/목적/보유기간)
- `form.name` 같은 접근은 HTMLFormElement 속성과 충돌하므로 `form.elements.name`으로 쓴다.

## 관리자 화면 (`admin.html`)
- 로그인 카드(네이비 패턴 배경) → 대시보드
- 상단: 사이트 화면 편집(4단계에서 사용), 신청 화면 보기, 로그아웃
- 상태별 현황 카드(누르면 그 상태로 조회)
- 신청 마감 설정: 스위치(확인 후 전환) + 마감 안내 제목·문구 저장
- **조회 조건 한 줄**: 검색 · 상태 · 타입 · 신청기간(시작~종료) · 조회 · 초기화를 flex 한 줄에 둔다. 1100px 미만에서만 줄바꿈된다.
  - 빠른 기간 버튼(오늘·7일·30일·전체)은 한 줄을 늘리지 않도록 목록 위 결과 건수 옆에 둔다.
- 목록: 체크박스, 번호, 신청일시, 이름, 연락처(tel 링크), 타입, 방문희망일, 문의/메모, 마케팅, 상태(바로 변경), 상세·삭제
- 선택 삭제, CSV 다운로드(현재 필터 반영), 페이지 크기, 페이지네이션, 상세·메모 모달
- 관리자 페이지에는 AOS를 넣지 않는다(footer partial 미사용).

## 확인 방법 (비밀번호를 노출하지 않고)
- API: `.env`에서 셸 변수로 비밀번호를 읽어 curl로 로그인 → 쿠키 파일로 나머지 호출. 값은 출력하지 않는다.
- 브라우저: 잘못된 비밀번호로 로그인 오류 화면을 확인한 뒤, curl로 받은 세션 토큰을 쿠키로 넣어 대시보드를 확인한다. 테스트가 끝나면 로그아웃하고 토큰 파일을 지운다.
- zsh에서는 `J='-H Content-Type:...'` 같은 변수가 단어 분리되지 않으니 함수나 따옴표 인자로 넘긴다.
