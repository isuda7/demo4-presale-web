# 프론트엔드 구조와 구현 기준 (홍보 사이트)

## 폴더
```
api/index.js                 # Vercel Function 진입점 (assets/site/api-index.js)
backend/src/{app,db,server}.js  # 이 단계에서는 health·content API 정도만, DB 연결은 assets/site/db.js
frontend/
  index.html, <메뉴>.html     # 메인 + 메뉴별 페이지
  partials/                   # head, header, cta, footer, aos-setup (@include)
  public/images/              # 카탈로그 추출 WebP
  src/styles/                 # main.css(진입점) → tokens, base, components, site
  src/js/                     # main.js(공통 렌더러), site.js(헤더·라이트박스·AOS·편집값 반영)
  src/data/                   # notes.json, units.js
  vite.config.js              # assets/site/vite.config.js (include 플러그인 + 멀티페이지 자동 수집)
vercel.json                   # assets/site/vercel.json (/api/* → /api?__path=)
.env.example                  # assets/site/env.example (이름만)
```
- 개발 실행은 루트 `npm run dev` 하나로 API(8787)와 Vite(5173)를 함께 띄운다(concurrently).
- 로컬 DB는 `TURSO_DATABASE_URL`이 비어 있으면 `backend/data/local.db` 파일을 쓴다(assets/site/db.js).

## 메뉴별 페이지
- 메인(`index.html`)은 히어로와 메뉴 카드(각 메뉴로 이동)만 둔다. 카탈로그 내용은 메뉴 페이지로 나눈다.
- 메뉴는 카탈로그 장 구성을 따른다(예: 프리미엄 / 입지환경 / 단지설계 / 커뮤니티 / 시스템 / 세대안내 / 배치도 / 유의사항).
- 메뉴 페이지 상단에는 서브비주얼(영문 라벨, 메뉴명, 한 줄 설명, 브레드크럼)을 둔다.
- 내비게이션은 헤더 GNB 하나다. 각 링크에 `data-menu="<page>"`를 달고 `body[data-page]`와 같으면 활성 표시한다. 서브내비(LNB)를 따로 두지 않는다.
- 헤더·푸터·CTA는 `partials/`에 한 번만 쓰고 `<!-- @include header.html -->`로 넣는다.

## 스타일 로딩 (첫 화면 깜빡임 방지)
- CSS는 JS에서 import하지 않는다. `partials/head.html` 맨 위에 `<link rel="stylesheet" href="/src/styles/main.css">`를 둔다. Vite가 개발에서는 그대로 서빙하고, 빌드에서는 번들 링크로 바꾼다.
- 첫 화면을 막는 외부 CSS는 최소화한다(본 서체 1벌만, 대체 서체 CDN 금지).
- 확인: `performance.getEntriesByType('resource')`에서 CSS의 `renderBlockingStatus`가 blocking이고, `responseEnd`가 first-paint보다 빠른지 개발·빌드(`vite preview`) 모두 본다.

## 헤더
- 기본(투명) 상태에 배경 블러를 넣는다. 헤더 자체에 `backdrop-filter`를 주면 모바일 전체화면 메뉴(fixed)의 기준이 헤더 높이로 바뀌어 메뉴가 갇힌다. 그래서 `.site-header::before`에 블러와 옅은 메인컬러 틴트를 주고 z-index:-1로 깐다.
- 스크롤하면 단색 헤더로 바뀐다(`is-solid`).
- 모바일 메뉴는 전체화면이다. 데스크톱용 헤더 버튼은 모바일에서 숨기되, `.btn`의 display가 뒤에서 덮지 않도록 선택자 우선순위를 확인한다.

## AOS (스크롤 등장 효과) — 사이트 전체 공통
- `npm i aos` 후 `assets/site/aos-setup.html`을 `partials/`에 두고 `footer.html` 끝에서 include한다.
- 인라인 스크립트가 첫 페인트 전에 대상에 `data-aos`를 부여하고, 값의 단일 출처(window.XI_AOS)가 된다. `site.js`가 같은 값으로 `AOS.init`한다.
- 첫 화면(히어로·서브비주얼): 로드 시 16px, 800ms, 두 번째 요소부터 150ms
- 섹션 비주얼·텍스트: fade-up 24px, 700ms, ease-out, offset 80, once, 두 번째 요소부터 100ms
- 전폭 배경형 비주얼: fade(이동 없음)
- 카드 묶음: 왼쪽부터 100ms 간격, 지연은 3번째까지
- 바깥 요소가 대상이면 안쪽 요소에는 붙이지 않는다. 등장이 끝나면 data-aos 속성을 걷어내 hover 전환을 지킨다. 탭 전환과 `details` 열림 시 `AOS.refresh()`.
- 제외는 `data-aos-off`. 동작 줄이기 환경과 관리자 편집 모드에서는 끈다.
- 대상 요소의 기본 위치를 transform으로 잡지 않는다.

## 포커스
- `:focus-visible`에만 사이트 포인트 컬러로 표시한다(흰 배경 대비 3:1 이상). 브라우저 기본 파란 링을 그대로 두지 않는다.
- 어두운 바 위의 버튼은 외곽선 대신 포인트 컬러 밑줄과 은은한 하이라이트로 표시한다.

## 다음 단계를 위한 준비 (인라인 편집 대비)
- 편집 대상이 될 문구·버튼·이미지에 `data-edit` 속성을 단다. 중요한 것은 고정 키(`data-edit="hero.title"`)를 쓰고, 나머지는 빈 값으로 두면 페이지·섹션·순번으로 자동 키가 붙는다.
- 오버레이 아래 깔린 배경 이미지(히어로, 서브비주얼, 전폭 비주얼) 영역에는 `data-edit-bg`를 단다.
- 줄바꿈이 있는 문구는 `white-space: pre-line`으로 소스 줄바꿈을 살린다.

## 기타 공통 컴포넌트
- 도면·배치도·지도는 라이트박스(클릭 확대)로 본다.
- 유의사항(※)은 섹션마다 접이식(`details`)으로 원문을 넣는다.
- 평면은 타입 탭으로 보여 주고, `?type=84a`처럼 주소로 특정 타입 탭을 열 수 있게 한다.
- 그리드 자식에는 `min-width: 0`을 줘서 표·이미지가 모바일 폭을 밀어내지 않게 한다.
