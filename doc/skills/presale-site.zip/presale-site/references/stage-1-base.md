# 1단계 — 기본 환경

프로젝트의 뼈대를 만든다. 화면은 비어 있어도 되고, "로컬에서 돌아가고, 환경변수만 넣으면 배포되는 구조"가 나오면 끝이다.

## 시작 전 확인
1. **카탈로그 파일**: 요청에 PDF 경로가 없으면 묻는다. 이 단계에서는 파일 위치만 확인하고 분석은 2단계에서 한다.
2. **이미 진행된 상태인지**: `package.json`, `frontend/`, `backend/`가 이미 있으면 새로 만들지 말고, 아래 완료 기준에서 빠진 것만 보완한다.
3. 다른 것은 묻지 않는다.

## 이 단계의 지시사항
아래는 사용자가 직접 정한 지시사항이다. 하나도 빠뜨리지 않는다.

**역할 / 진행 방식**
* 너는 분양사이트 제작만 30년 해온 베테랑 크리에이터 디자이너야.
* 분양 카탈로그(PDF)를 이용해서 분양사이트를 제작해줘.
* 먼저 지시사항을 프롬프트로 정리해서 루트/doc/ 폴더에 md 문서로 만들고, 그 프롬프트대로 첨부파일을 참조해서 진행해.
* 로컬에서 먼저 실제 환경으로 세팅해서 돌려보고, 나중에 배포만 하면 되는 상태로 만들어줘.
* 모든 최종 피드백은 한국어로 설명해줘.

**기술 스펙**
* 코드는 GitHub로 관리해.
* 실행과 배포는 Vercel로 해. 프론트 빌드와 백엔드(Hono) 실행을 같이 하고, 저장소에 푸시하면 자동으로 빌드·배포되게 해줘.
* 신청 데이터는 Turso에 저장해.
* 프론트엔드는 HTML/CSS/JS로, Vite 멀티페이지로 만들어.
* 백엔드와 프론트엔드 폴더를 나눠서 설계해.

**보안**
* 관리자 비밀번호와 토큰 비밀값은 코드나 문서에 적지 말고 환경변수로만 다뤄줘.

## 진행 순서
1. **요구사항 문서**: 스킬의 "항상 지키는 규칙"과 4단계 구성을 정리해 `doc/prompt.md`로 남긴다. 각 단계를 진행할 때 그 단계 지시사항을 `doc/0N-*.md`로 덧붙인다.
2. **공통 규칙 파일**: `assets/common-CLAUDE.md`를 프로젝트 루트 `CLAUDE.md`로 복사한다. 이미 다른 CLAUDE.md가 있으면 덮어쓰지 말고 아래에 덧붙인다.
3. **폴더 구조**
   ```
   api/index.js            # Vercel Function 진입점 → assets/site/api-index.js
   backend/src/app.js      # Hono 앱 (basePath /api, 보안 헤더, 오류 처리, GET /api/health)
   backend/src/db.js       # Turso 연결 + 스키마 보장 → assets/site/db.js
   backend/src/server.js   # 로컬 개발 서버(@hono/node-server, 포트 8787)
   backend/scripts/        # migrate.js (스키마 생성)
   frontend/               # Vite 루트: index.html, partials/, public/, src/
   frontend/vite.config.js # → assets/site/vite.config.js (include 플러그인, *.html 자동 수집, /api 프록시)
   vercel.json             # → assets/site/vercel.json (/api/* → /api?__path=)
   .env.example            # → assets/site/env.example (이름만)
   ```
4. **package.json**: 의존성 `hono`, `@hono/node-server`, `@libsql/client`, 개발 의존성 `vite`, `concurrently`. 스크립트:
   - `dev`: API와 Vite 동시 실행 (`node --env-file-if-exists=.env --watch backend/src/server.js` + `vite --config frontend/vite.config.js`)
   - `build`, `preview`, `db:migrate`
5. **환경변수**: `ADMIN_PASSWORD`, `ADMIN_TOKEN_SECRET`(32자 이상), `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`
   - 로컬 `.env`는 `openssl rand`로 만든 값으로 채우고, 값은 출력하지 않는다. `umask 077`로 만든다.
   - `TURSO_DATABASE_URL`이 비면 로컬 파일 DB(`backend/data/local.db`)를 쓴다.
   - Vercel(운영)에서 비어 있으면 오류를 낸다.
6. **.gitignore**: `node_modules/`, `frontend/dist/`, `backend/data/`, `.vercel/`, `.env`, `.env.*`(`.env.example` 제외)
7. **빈 메인 페이지**: `frontend/index.html`에 프로젝트명만 있는 페이지와 `partials/head.html`을 둔다. CSS는 head의 `<link>`로 연결한다(JS에서 import하지 않음 — 첫 화면 깜빡임 방지).
8. **실행 확인**: `npm run dev`로 띄워 메인 페이지와 `/api/health`를 확인하고, `npm run build`가 통과하는지 본다.
9. **README**: 로컬 실행, 환경변수 이름, Turso DB 생성(`turso db create`, `show --url`, `tokens create`), GitHub 푸시, Vercel Import와 환경변수 등록 절차를 쓴다.
10. **커밋**: 첫 커밋으로 남긴다. 푸시는 사용자가 요청할 때만 한다.

## 완료 기준
- [ ] `doc/prompt.md`와 루트 `CLAUDE.md`(공통 규칙)가 있다.
- [ ] `npm run dev` 하나로 API(8787)와 화면(5173)이 함께 뜨고, `/api/health`가 200이다.
- [ ] `npm run build`가 통과하고, `vercel.json`의 출력 폴더·재작성 규칙이 빌드 결과와 맞는다.
- [ ] `api/index.js`로 `/api?__path=health`를 호출하면 200이다(Vercel 경로 재작성 모의 확인).
- [ ] `.env`는 git에서 제외되어 있고, 저장소 어디에도 비밀값이 없다(.env 값으로 검색해 0건).
- [ ] README에 배포 절차가 있다.

## 다음 단계
"2단계(홍보 사이트 구축)를 진행하려면 말씀해 주세요."
