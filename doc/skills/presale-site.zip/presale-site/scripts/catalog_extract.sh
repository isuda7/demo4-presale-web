#!/usr/bin/env bash
# 카탈로그 PDF를 분석용 자료로 펼친다.
# 사용법: catalog_extract.sh <카탈로그.pdf> <작업폴더(스크래치)>
# 결과:
#   <작업폴더>/text/t<N>.txt     페이지별 텍스트 (pdftotext)
#   <작업폴더>/render150/r-NN.jpg 150dpi 페이지 렌더 (크롭 원본)
#   <작업폴더>/grid/gNN.jpg       992px 폭 + 50px 격자 미리보기 (크롭 좌표 읽기용)
#   <작업폴더>/img/               PDF에 들어 있는 원본 사진 (pdfimages -j)
#   <작업폴더>/img-sheet.jpg      추출 사진 목록 한 장 (어떤 사진을 쓸지 고르기용)
# 필요: poppler(pdftoppm, pdftotext, pdfimages, pdfinfo), python3 + Pillow
set -euo pipefail
PDF="$1"; OUT="$2"
mkdir -p "$OUT"/{text,render150,grid,img}
cp "$PDF" "$OUT/catalog.pdf"
PAGES=$(pdfinfo "$OUT/catalog.pdf" | awk '/^Pages:/{print $2}')
echo "pages: $PAGES"
for i in $(seq 1 "$PAGES"); do pdftotext -f "$i" -l "$i" "$OUT/catalog.pdf" "$OUT/text/t$i.txt"; done
pdftoppm -r 150 -jpeg -jpegopt quality=90 "$OUT/catalog.pdf" "$OUT/render150/r"
for i in $(seq 1 "$PAGES"); do pdfimages -j -f "$i" -l "$i" "$OUT/catalog.pdf" "$OUT/img/p$i" || true; done
python3 - "$OUT" <<'EOF'
import sys, glob, os
from PIL import Image, ImageDraw
out = sys.argv[1]
# 격자 미리보기: 모든 크롭 좌표는 이 992px 폭 기준으로 적는다
for f in sorted(glob.glob(f'{out}/render150/r-*.jpg')):
    n = os.path.basename(f)[2:4]
    im = Image.open(f); h = round(im.height * 992 / im.width)
    im = im.resize((992, h)); d = ImageDraw.Draw(im)
    for x in range(0, 992, 50):
        d.line([(x, 0), (x, h)], fill=(255, 0, 0) if x % 100 == 0 else (255, 180, 180))
        if x % 100 == 0: d.text((x + 2, 2), str(x), fill=(255, 0, 0))
    for y in range(0, h, 50):
        d.line([(0, y), (992, y)], fill=(255, 0, 0) if y % 100 == 0 else (255, 180, 180))
        if y % 100 == 0: d.text((2, y + 2), str(y), fill=(255, 0, 0))
    im.save(f'{out}/grid/g{n}.jpg', quality=75)
# 추출 사진 목록
items = []
for f in sorted(glob.glob(f'{out}/img/*')):
    try: im = Image.open(f)
    except Exception: continue
    if im.width >= 400 and im.height >= 250: items.append((f, im))
if items:
    tw, th, cols = 240, 170, 8
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * tw, rows * (th + 14)), 'white'); d = ImageDraw.Draw(sheet)
    for i, (f, im) in enumerate(items):
        t = im.convert('RGB'); t.thumbnail((tw - 4, th - 4)); x, y = (i % cols) * tw, (i // cols) * (th + 14)
        sheet.paste(t, (x + 2, y + 2)); d.text((x + 2, y + th), f'{os.path.basename(f)} {im.mode}', fill='red')
    sheet.save(f'{out}/img-sheet.jpg', quality=75)
print('done')
EOF
