"""페이지별 '※' 유의사항과 '•' 항목을 문단 단위로 모아 notes.json으로 저장한다.

사용법: python3 extract_notes.py <작업폴더> <출력 json> [시작페이지=2]
결과: {"3": ["문단", ...], ...} — 화면에서는 페이지별 접이식 유의사항으로 쓴다.
주의: 텍스트 레이어가 겹친 페이지는 문장이 뒤섞여 나올 수 있다. 결과를 훑어보고
      깨진 페이지는 해당 항목을 지우고 화면 이미지를 보며 직접 옮겨 적는다.
"""
import sys, json, re, glob, os

work, out = sys.argv[1], sys.argv[2]
start = int(sys.argv[3]) if len(sys.argv) > 3 else 2
pages = sorted(int(re.search(r't(\d+)\.txt$', f).group(1)) for f in glob.glob(f'{work}/text/t*.txt'))
res = {}
for p in pages:
    if p < start: continue
    lines = open(f'{work}/text/t{p}.txt', encoding='utf-8', errors='ignore').read().split('\n')
    paras, cur = [], None
    for ln in lines:
        s = ln.strip().replace('\x0c', '')
        if s.startswith(('※', '•')):
            if cur: paras.append(cur)
            cur = s.lstrip('※•').strip()
        elif cur is not None:
            if not s: paras.append(cur); cur = None
            else: cur += ' ' + s
    if cur: paras.append(cur)
    seen = []
    for x in paras:
        x = re.sub(r'\s+', ' ', x).strip()
        if len(x) < 8 or any(x in y for y in seen): continue
        seen = [y for y in seen if y not in x] + [x]
    res[str(p)] = seen
os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print({k: len(v) for k, v in res.items()})
