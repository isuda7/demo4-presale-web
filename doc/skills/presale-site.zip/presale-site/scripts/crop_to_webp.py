"""카탈로그 렌더/추출 이미지를 웹용 WebP로 잘라 저장한다.

사용법: python3 crop_to_webp.py <spec.json> <작업폴더> <출력폴더(frontend/public/images)>

spec.json 예시 — 좌표는 grid/gNN.jpg(992px 폭) 기준:
[
  {"name": "location-map", "page": 3, "box": [35, 185, 520, 578], "dpi": 200},
  {"name": "exterior", "image": "p4-000.jpg"},
  {"name": "unit-59-basic", "page": 12, "box": [25, 112, 485, 252], "dpi": 200, "trim": true},
  {"name": "hero", "image": "p2-000.jpg", "maxw": 2400, "q": 78}
]
- page+box: 해당 페이지를 dpi(기본 150)로 렌더해 잘라낸다. 텍스트·도면처럼 벡터가 섞인 영역에 쓴다.
- image: PDF에 들어 있던 원본 사진(img/ 폴더)을 그대로 쓴다. 사진은 이쪽이 화질이 좋다.
- trim: 흰 여백을 자동으로 잘라낸다(평면도 등).
CMYK 원본은 색이 뒤집힐 수 있으니, 그런 사진은 page+box 렌더로 대신한다.
"""
import json, subprocess, sys, os
from PIL import Image, ImageChops

spec_path, work, out = sys.argv[1:4]
os.makedirs(out, exist_ok=True)
cache = {}

def render(page, dpi):
    key = (page, dpi)
    if key not in cache:
        prefix = f'{work}/r{dpi}-{page}'
        if not os.path.exists(prefix + '.jpg'):
            subprocess.run(['pdftoppm', '-r', str(dpi), '-jpeg', '-jpegopt', 'quality=92', '-singlefile',
                            '-f', str(page), '-l', str(page), f'{work}/catalog.pdf', prefix], check=True)
        cache[key] = Image.open(prefix + '.jpg')
    return cache[key]

def trim(im, pad=24):
    bg = Image.new('RGB', im.size, (255, 255, 255))
    b = ImageChops.difference(im, bg).convert('L').point(lambda v: 255 if v > 18 else 0).getbbox()
    if not b: return im
    return im.crop((max(0, b[0] - pad), max(0, b[1] - pad), min(im.width, b[2] + pad), min(im.height, b[3] + pad)))

for s in json.load(open(spec_path, encoding='utf-8')):
    if 'image' in s:
        im = Image.open(f"{work}/img/{s['image']}").convert('RGB')
    else:
        src = render(s['page'], s.get('dpi', 150)); k = src.width / 992
        im = src.crop(tuple(round(v * k) for v in s['box'])).convert('RGB')
    if s.get('trim'): im = trim(im)
    maxw = s.get('maxw', 1920)
    if im.width > maxw: im = im.resize((maxw, round(im.height * maxw / im.width)), Image.LANCZOS)
    im.save(f"{out}/{s['name']}.webp", 'WEBP', quality=s.get('q', 82), method=6)
    print('saved', s['name'], im.size)
